<h1>Cow3</h1>
<img src="img/Screenshot_20211128-150048_Termux.jpg"></img><br/>
Tool crack Facebook. Multi Bruteforce Publik Version: 0.1.4
<h1>keunggulan</h1>
<h2>1. Tampilan lebih bagus</h2>
<p>Dibandingkan versi cow sebelumnya tampilan yang cow3 jauh lebih bagus menurut saya.</p>
<h2>2. Mendapatkan hasil lebih banyak</h2>
<p>Di versi cow3 ini kalian akan mendapatkan result yang lebih banyak dari versi cow sebelumnya. Dikarenakan, di versi ini sudah memakai beberapa kondisi penanda yang membuat lebih banyak hasil.</p>
<h2>3. Fixed bug</h2>
<p>Di versi cow sebelumnya banyak sekali bug yang belum saya bereskan bahkan hingga saat ini. Akan tetapi di versi ini bug dan error sudah saya bereskan dan bahkan hanya sedikit saja. Jika menemukan bug atau error silahkan hubungi WhatsApp Latif.</p>
<h2>4. Terdapat cp detector</h2>
<img src="img/Screenshot_20211128-152001_Termux.jpg"></img>
<p>Apa itu cp detector? Cp detector adalah tool untuk mengecek opsi checkpoint dari akun Facebook yang terkena checkpoint. Selengkapnya cek sc saya sebelumnya yang bernama cek_opsi_checkpoint.</p>
<h1>Installed</h1>
<h2>Install Tool</h2>
<pre>
<code>
$ pkg install git
$ git clone https://github.com/Latip176/cow3
$ pkg install python
</code>
</pre>
<h2>Menjalankan Tool</h2>
<pre>
<code>
$ cd cow3
$ pip install -r requirements.txt
$ python app.py
</code>
</pre>
<h1>Social Media</h1>
<li><a href="https://latip176.my.id/">Website</a></li>
<li><a href="https://www.facebook.com/latip176.my.id">Facebook</a></li>
<li><a href="https://www.instagram.com/latif176_">Instagram</a></li>
<h1>terima kasih kepada</h1>
<li>XNSCODE TEAM</li>
<h1>Note!</h1>
<p>Jika ingin mengambil beberapa fitur didalam sc ini silahkan kasih nama saya selaku Author. Dan harap meminta ijin terlebih dahulu.
<li>PYTHON SUKABUMI PROGRAMMERS</li>
